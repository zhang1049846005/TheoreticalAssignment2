package com.jasonwei.java;

/**
 * Created by Jason_Wei on 2015/10/26.
 */
public class ATM
{
    private BankDatabase bankDatabase;

    public ATM()
    {
        bankDatabase = new BankDatabase();
    }

    public boolean authenticateUser(int accountNumber, int pin)
    {
        return bankDatabase.authenticateUser(accountNumber, pin);
    }

    public String getBalance()
    {
        double availableBalance = bankDatabase.getAvailableBalance(Integer.parseInt(ATMCaseStudy.sid));

        double totalBalance = bankDatabase.getTotalBalance(Integer.parseInt(ATMCaseStudy.sid));

        return "\nBalance Information:\n     - Available balance: " + availableBalance + "\n     - Total balance: " + totalBalance;
    }

    public boolean withdraw(int amount)
    {
        return bankDatabase.takeMoney(Integer.parseInt(ATMCaseStudy.sid), amount);
    }

    public void deposit(int amount)
    {
        bankDatabase.insertMoney(Integer.parseInt(ATMCaseStudy.sid), amount);
    }
}
