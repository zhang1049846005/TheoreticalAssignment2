package com.jasonwei.java;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

/**
 * Created by Jason_Wei on 2015/10/26.
 */
public class ATMCaseStudy
{
    static String sid = "";
    static String pwd = "";
    static String amount = "";

    static int eventType = 1;

    static String welcome = "Welcome";
    static String inputSid = "\nPlease enter your account number: \n";
    static String inputPwd = "\nEnter your PIN: \n";
    static String wrongPwd = "Invalid account number or PIN. Please try again.";

    public static void main( String[] args )
    {
        ATM atm = new ATM();

        JFrame window = new JFrame("ATM Emulator v0.0");

        window.setResizable(false);

        window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        window.setSize(500, 500);

        try
        {
            window.setIconImage(ImageIO.read(new File("resources/icon.png")));
        } catch (IOException e)
        {
            e.printStackTrace();
        }

        window.setVisible(true);

        window.setLayout(null);

        JTextArea output = new JTextArea();
        output.setDisabledTextColor(Color.BLACK);
        window.add(output);
        output.setBounds(20, 20, 360, 180);
        output.setEnabled(false);

        JButton balance = new JButton();
        balance.setText("Balance");
        window.add(balance);
        balance.setBounds(400, 0, 100, 55);
        balance.setFocusPainted(false);
        balance.setEnabled(false);
        balance.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventType = 4;
                switch (eventType) {
                    case 4:
                        output.setText(atm.getBalance());
                        break;
                }
                eventType = 3;
            }
        });

        JButton withdraw = new JButton();
        withdraw.setText("Withdraw");
        window.add(withdraw);
        withdraw.setBounds(400, 55, 100, 55);
        withdraw.setFocusPainted(false);
        withdraw.setEnabled(false);
        withdraw.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                amount = "";
                eventType = 5;
                switch (eventType) {
                    case 5:
                        output.setText(atm.getBalance() + "\n\nInput amount:\n");
                        break;
                }
            }
        });

        JButton deposit = new JButton();
        deposit.setText("Deposit");
        window.add(deposit);
        deposit.setBounds(400, 110, 100, 55);
        deposit.setFocusPainted(false);
        deposit.setEnabled(false);
        deposit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                amount = "";
                eventType = 6;
                switch (eventType) {
                    case 6:
                        output.setText("Input deposit amount:\n");
                        amount = "";
                        break;
                }
            }
        });

        JButton exit = new JButton();
        exit.setText("Exit");
        window.add(exit);
        exit.setBounds(400, 165, 100, 55);
        exit.setFocusPainted(false);
        exit.setEnabled(false);
        exit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eventType = 7;
                switch (eventType) {
                    case 7:
                        sid = "";
                        pwd = "";
                        balance.setEnabled(false);
                        withdraw.setEnabled(false);
                        deposit.setEnabled(false);
                        exit.setEnabled(false);
                        output.setText(welcome + inputSid);
                        break;
                }
                eventType = 1;
            }
        });

        JButton one = new JButton();
        one.setText("1");
        window.add(one);
        one.setBounds(0, 220, 70, 63);
        one.setFocusPainted(false);
        one.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "1";
                        output.setText(output.getText() + "1");
                        break;
                    case 2:
                        pwd += "1";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "1";
                        output.setText(output.getText() + "1");
                        break;
                    case 6:
                        amount += "1";
                        output.setText(output.getText() + "1");
                        break;
                }
            }
        });

        JButton two = new JButton();
        two.setText("2");
        window.add(two);
        two.setBounds(70, 220, 70, 63);
        two.setFocusPainted(false);
        two.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "2";
                        output.setText(output.getText() + "2");
                        break;
                    case 2:
                        pwd += "2";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "2";
                        output.setText(output.getText() + "2");
                        break;
                    case 6:
                        amount += "2";
                        output.setText(output.getText() + "2");
                        break;
                }
            }
        });

        JButton three = new JButton();
        three.setText("3");
        window.add(three);
        three.setBounds(140, 220, 70, 63);
        three.setFocusPainted(false);
        three.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "3";
                        output.setText(output.getText() + "3");
                        break;
                    case 2:
                        pwd += "3";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "3";
                        output.setText(output.getText() + "3");
                        break;
                    case 6:
                        amount += "3";
                        output.setText(output.getText() + "3");
                        break;
                }
            }
        });

        JButton four = new JButton();
        four.setText("4");
        window.add(four);
        four.setBounds(0, 283, 70, 63);
        four.setFocusPainted(false);
        four.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "4";
                        output.setText(output.getText() + "4");
                        break;
                    case 2:
                        pwd += "4";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "4";
                        output.setText(output.getText() + "4");
                        break;
                    case 6:
                        amount += "4";
                        output.setText(output.getText() + "4");
                        break;
                }
            }
        });

        JButton five = new JButton();
        five.setText("5");
        window.add(five);
        five.setBounds(70, 283, 70, 63);
        five.setFocusPainted(false);
        five.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "5";
                        output.setText(output.getText() + "5");
                        break;
                    case 2:
                        pwd += "5";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "5";
                        output.setText(output.getText() + "5");
                        break;
                    case 6:
                        amount += "5";
                        output.setText(output.getText() + "5");
                        break;
                }
            }
        });

        JButton six = new JButton();
        six.setText("6");
        window.add(six);
        six.setBounds(140, 283, 70, 63);
        six.setFocusPainted(false);
        six.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "6";
                        output.setText(output.getText() + "6");
                        break;
                    case 2:
                        pwd += "6";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "6";
                        output.setText(output.getText() + "6");
                        break;
                    case 6:
                        amount += "6";
                        output.setText(output.getText() + "6");
                        break;
                }
            }
        });

        JButton seven = new JButton();
        seven.setText("7");
        window.add(seven);
        seven.setBounds(0, 346, 70, 63);
        seven.setFocusPainted(false);
        seven.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "7";
                        output.setText(output.getText() + "7");
                        break;
                    case 2:
                        pwd += "7";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "7";
                        output.setText(output.getText() + "7");
                        break;
                    case 6:
                        amount += "7";
                        output.setText(output.getText() + "7");
                        break;
                }
            }
        });

        JButton eight = new JButton();
        eight.setText("8");
        window.add(eight);
        eight.setBounds(70, 346, 70, 63);
        eight.setFocusPainted(false);
        eight.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "8";
                        output.setText(output.getText() + "8");
                        break;
                    case 2:
                        pwd += "8";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "8";
                        output.setText(output.getText() + "8");
                        break;
                    case 6:
                        amount += "8";
                        output.setText(output.getText() + "8");
                        break;
                }
            }
        });

        JButton nine = new JButton();
        nine.setText("9");
        window.add(nine);
        nine.setBounds(140, 346, 70, 63);
        nine.setFocusPainted(false);
        nine.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "9";
                        output.setText(output.getText() + "9");
                        break;
                    case 2:
                        pwd += "9";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "9";
                        output.setText(output.getText() + "9");
                        break;
                    case 6:
                        amount += "9";
                        output.setText(output.getText() + "9");
                        break;
                }
            }
        });

        JButton zero = new JButton();
        zero.setText("0");
        window.add(zero);
        zero.setBounds(0, 409, 70, 63);
        zero.setFocusPainted(false);
        zero.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        sid += "0";
                        output.setText(output.getText() + "0");
                        break;
                    case 2:
                        pwd += "0";
                        output.setText(output.getText() + "*");
                        break;
                    case 5:
                        amount += "0";
                        output.setText(output.getText() + "0");
                        break;
                    case 6:
                        amount += "0";
                        output.setText(output.getText() + "0");
                        break;
                }
            }
        });

        JButton enter = new JButton();
        enter.setText("Enter");
        window.add(enter);
        enter.setBounds(70, 409, 140, 63);
        enter.setFocusPainted(false);
        enter.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switch (eventType)
                {
                    case 1:
                        eventType = 2;
                        output.setText(output.getText() + inputPwd);
                        break;
                    case 2:
                        if (!sid.equals("") && !pwd.equals("") && atm.authenticateUser(Integer.parseInt(sid), Integer.parseInt(pwd)))
                        {
                            eventType = 3;
                            output.setText("User" + sid + ", welcome!\n Press keys to begin your transaction");
                            balance.setEnabled(true);
                            deposit.setEnabled(true);
                            withdraw.setEnabled(true);
                            exit.setEnabled(true);
                        }
                        else
                        {
                            eventType = 1;
                            sid = "";
                            pwd = "";
                            output.setText(wrongPwd + inputSid);
                        }
                        break;
                    case 5:
                        if (amount.equals(""))
                        {
                            output.setText("Invalid amount! Try again:\n");
                        }
                        else
                        {
                            if (atm.withdraw(Integer.parseInt(amount)))
                            {
                                output.setText("Take your money!");
                                amount = "";
                                eventType = 3;
                            }
                            else
                            {
                                output.setText("You don't have so much money available! Try less money:\n");
                                amount = "";
                            }
                        }
                        break;
                    case 6:
                        if (amount.equals(""))
                        {
                            output.setText("Invalid amount! Try again:\n");
                        }
                        else
                        {
                            atm.deposit(Integer.parseInt(amount));
                            output.setText("You've been deposit " + amount + "!\n#The money is temporarily unavailable#");
                            amount = "";
                        }
                        break;
                }
            }
        });

        JLabel withdrawLabel = new JLabel(new ImageIcon("resources/withdraw.png"));
        window.add(withdrawLabel);
        withdrawLabel.setBounds(210, 220, 286, 127);

        JLabel depositLabel = new JLabel(new ImageIcon("resources/deposit.png"));
        window.add(depositLabel);
        depositLabel.setBounds(210, 347, 286, 127);

        output.setText(welcome + inputSid);

        JOptionPane.showConfirmDialog(null, "Account in BankDatabase:12345   PIN:54321",
                "!!!", JOptionPane.CANCEL_OPTION);
    }
}
