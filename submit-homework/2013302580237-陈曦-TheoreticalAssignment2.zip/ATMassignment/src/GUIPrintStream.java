import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.SwingUtilities;
import javax.swing.text.JTextComponent;

public class GUIPrintStream extends PrintStream{
	private JTextComponent textCom;
	private StringBuffer stringb=new StringBuffer();
	
	public GUIPrintStream(OutputStream out)
	{
		super(out);
	}
	public GUIPrintStream (OutputStream out,JTextComponent textCom)
	{
		super(out);
		this.textCom=textCom;
	}
	
	public void write (byte [] buf,int off,int len)
	{
		final String message=new String(buf, off, len);
		SwingUtilities.invokeLater(new Runnable(){
			public void run()
			{
				stringb.append(message);
				textCom.setText(stringb.toString());
			}
		});
	}

}
