import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class TextAreaFrame extends JFrame
{
	private JPanel buttonj;
	private JTextArea jtexta;
	private JButton[] jbutton;
	private GUIPrintStream out;
	private ATM atm;
	private String svalue="";
	public ATM getATM()
	{
		return atm;
	}
	
	public TextAreaFrame()
	{
		atm=new ATM();
		setTitle("ATMassignment");
		
		jbutton=new JButton[12];
		buttonj=new JPanel();
		buttonj.setLayout(new  GridLayout(4,3));
		for(int i=0;i<jbutton.length;i++)
		{
			jbutton[i]=new JButton(""+(i+1));
			
			if(i>=9)
			{
				switch(i)
				{
				case 9:
					jbutton[i]=new JButton("Enter");
					break;
				case 10:
					jbutton[i]=new JButton(""+(0));
					break;
				case 11:
					jbutton[i]=new JButton("<-");
				    break;
				}
			
			}

			
			buttonj.add(jbutton[i]);
		}
		
		jbutton[0].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						jtexta.append("1");
						svalue+="1";
					}
				}
				);
		jbutton[1].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="2";
						jtexta.setText(jtexta.getText()+"2");
					}
				}
				);
		jbutton[2].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="3";
						jtexta.setText(jtexta.getText()+"3");
					}
				}
				);
		jbutton[3].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="4";
						jtexta.setText(jtexta.getText()+"4");
					}
				}
				);
		jbutton[4].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="5";
						jtexta.setText(jtexta.getText()+"5");
					}
				}
				);
		jbutton[5].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="6";
						jtexta.setText(jtexta.getText()+"6");
					}
				}
				);
		jbutton[6].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="7";
						jtexta.setText(jtexta.getText()+"7");
					}
				}
				);
		jbutton[7].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="8";
						jtexta.setText(jtexta.getText()+"8");
					}
				}
				);
		jbutton[8].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="9";
						jtexta.setText(jtexta.getText()+"9");
					}
				}
				);
		jbutton[9].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(svalue!="")
						{
						atm.keypad.setInput(Integer.parseInt(svalue));
						atm.keypad.setEndInput(true);
						svalue="";
						}
						
					}
				}
				);
		jbutton[10].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						svalue+="0";
						jtexta.setText(jtexta.getText()+"0");
					}
				}
				);
		jbutton[11].addActionListener(
				new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						if(svalue.length()!=0)
						{
							svalue=jtexta.getText();
							svalue=svalue.substring(0,svalue.length()-1);
							jtexta.setText(svalue);
						}

					}
				}
				);
		add(buttonj,BorderLayout.SOUTH);		
    	String content="";  	
    	jtexta=new JTextArea(content,300,150);
        out=new GUIPrintStream(System.out,jtexta);
        System.setOut(out);
    	add(new JScrollPane(jtexta));
	}
}

	


